# [Fwargo.com](https://fwargo.herokuapp.com/)
Personal Website Using Node.JS
This is a collection of tabletop games I have created in JS with algorithms to solve them

## Sodoku
Backtracking is used here to solve the Sudoku game. This can be seen by clicking the solve button

## Reversi
Also known as Othello. This game uses a version of Heuristic Minimax with Alpha-Beta pruning. The search depth can be adjusted resulting in a tradeoff between speed and solution quality. 

# Backgammon
 This uses a basic heuristic evaluation strategy to pick moves. 
